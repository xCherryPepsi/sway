#!/bin/bash
killall xdg-desktop-portal
